const MENU_TIMEOUT = 120000;

const CATEGORIES = [
    [1, 'التـحـمـيـل', 'downloads', '📂'],
    [2, 'الـمـجـمـوعـات', 'group', '🛡️'],
    [3, 'الـمـلـصـقـات', 'sticker', '🃏'],
    [4, 'الـمـطـوريـن', 'owner', '👑'],
    [5, 'امـثـلـه', 'example', '✳️'],
    [6, 'الـادوات', 'tools', '⚙️'],
    [7, 'الـبـحـث', 'search', '🔍'],
    [8, 'الادمــن', 'admin', '⚔️'],
    [9, 'الالــعـاب', 'games', '🎮'],
    [10, 'الچيف', 'gif', '🖼️'],
    [11, 'الـبــنـك', 'bank', '💳'],
    [12, 'الـذكـاء الاصـطـنـاعـي', 'ai', '🤖'],
    [13, 'الـبـوتـات الـفـرعـي', 'sub', '⛓️'],
    [14, 'مـعـلومـات الـبـوت', 'info', '📜'],
    [15, 'الـالــقــاب', 'nicknames', '🏷️'],
    [16, 'الـلـوجـوهــات', 'logos', '🎨'],
    [17, 'تـغـيـر الاصـوات', 'voices', '🎙️'],
    [18, 'أخــرى', 'other', '🔮']
];

const getCat = n => CATEGORIES.find(c => c[0] === n);

if (!global.menus) global.menus = {};

const clean = () => {
    const now = Date.now();
    Object.keys(global.menus).forEach(k => {
        if (now - global.menus[k].time > MENU_TIMEOUT) delete global.menus[k];
    });
};

const getImg = (bot) => {
    const { images } = bot.config.info;
    return Array.isArray(images) ? images[Math.floor(Math.random() * images.length)] : images;
};

const context = (jid, img) => ({
    mentionedJid: [jid],
    isForwarded: true,
    forwardingScore: 1,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '0029VbC75tvHltY0oNSC4m3z@newsletter',
        newsletterName: '𝐓𝐄𝐀𝐌 𝐃𝐄𝐕𝐎𝐍𝐈𝐂 || 𝑩𝑶𝑻',
        serverMessageId: 0
    },
    externalAdReply: {
        title: "🩸┇𝐾𝐼𝑅𝐴┇📖",
        body: "أنا هو إله العالم الجديد.. العدالة المطلقة تبدأ من هنا.",
        thumbnailUrl: img,
        sourceUrl: '',
        mediaType: 1,
        renderLargerThumbnail: true
    }
});

const menu = async (m, { conn, bot }) => {
    clean();
    
    const cmds = await bot.getAllCommands();
    const cats = {};
    
    cmds.forEach(c => {
        if (!c.usage?.length) return;
        const cat = c.category || 'other';
        if (!cats[cat]) cats[cat] = [];
        cats[cat].push(c);
    });

    const txt = `
📖 *حـان وقـت تـطـهـيـر الـعـالـم..* ⚔️
🩸 *اكـتـب اسـمـك فـي مـفـكـرة الـمـوت!*

❐═━━━═╊⊰🩸⊱╉═━━━═❐
${CATEGORIES.map(c => `┇ 🩸 ${c[0]} *قـسـم ${c[1]} ${c[3]}*`).join('\n')}
❐═━━━═╊⊰🩸⊱╉═━━━═❐
> *اختر رقم القسم المراد فتحه من المفكرة بدون نقاط.*`;

    const msg = await conn.sendMessage(m.chat, { 
        text: txt,
        contextInfo: context(m.sender, getImg(bot))
    }, { quoted: m });
  
    global.menus[msg.key.id] = { cats, chatId: m.chat, time: Date.now() };
};

menu.before = async (m, { conn, bot }) => {
    clean();
    
    const menuData = global.menus[m.quoted?.id];
    if (!menuData) return false;
    
    const cat = getCat(parseInt(m.text));
    if (!cat) {
        await conn.sendMessage(m.chat, { text: '❌ ┇ *اخـتـر رقـمـاً صـحـيـحـاً مـن الـمـفـكـرة فـقـط.*' }, { quoted: m });
        return true;
    }
    
    const cmds = menuData.cats[cat[2]];
    if (!cmds?.length) {
        await conn.sendMessage(m.chat, { text: '❌ ┇ *هـذا الـقـسـم لا يـحـتـوي عـلـى أوامـر حـالـيـاً.*' }, { quoted: m });
        return true;
    }
    
    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, id: m.quoted.id, fromMe: true } });
    delete global.menus[m.quoted.id];
    
    const cmdsList = cmds.map(c => `┇ ${cat[3]}  /${c.usage.join(`\n┇ ${cat[3]}  /`)}`).join('\n');
    
    await conn.sendMessage(m.chat, { 
        text: `
╭─┈──┈─⟞📖⟝─┈┈─┈─╮
┃ *قـسـم ${cat[1]} ${cat[3]}*
╰─┈──┈─⟞🩸⟝─┈──┈─╯

${cmdsList}

╭─┈─┈┈─⟞🩸⟝─┈┈─┈─╮
┃ *𝐃𝐄𝐕𝐎𝐍𝐈𝐂 𝐁𝐎𝐓  ⚚*
╰─┈──┈─⟞📖⟝─┈┈─┈─╯
> *الـعـدالـة سـوف تـتـحـقـق مـهـمـا كـلـف الأمـر.*`.trim(),
        contextInfo: context(m.sender, getImg(bot))
    }, { quoted: m });
    
    return true;
};

menu.command = ['اوامر1'];
export default menu;
