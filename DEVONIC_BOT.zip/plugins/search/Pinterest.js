async function test(m, { conn, bot, text }) {
  try {
    if (!text) return m.reply("*اكتب اسم الصورة بالانجليزي عشان تظهر لك📸*");
    
    const res = await bot.Api.search.pinterestImages({ q: text });
    const arr = res.data;
    
    if (!arr || arr.length === 0) {
      return m.reply("*⚠️ لا توجد نتائج*");
    }
    
    const start = Math.floor(Math.random() * (arr.length - 10));
    const selectedImages = arr.slice(start, start + 10);

    const cards = selectedImages.map((item, index) => {
      const title = item.title && item.title !== 'No title' ? item.title : `Image ~ ${index + 1}`;
      
      return {
        imageUrl: item.url,
        bodyText: `*${title}*`,
        footerText: item.owner ? `👤 ${item.owner} • Pinterest` : '📌 Pinterest Image',
        buttons: [
          { name: 'cta_url', params: { display_text: '🔗╎ رؤيـتـهـا', url: item.pinUrl || item.url } },
          { name: 'cta_copy', params: { display_text: '📋╎ نـسـخ الـرابــط', copy_code: item.url } }
        ]
      };
    });

    return await conn.sendCarousel(m.chat, {
      headerText: `📸 البحث الخاص بك → *[ ${text} ]* `,
      globalFooterText: 'اسحب لروئية المزيد من الصور',
      cards: cards,
      mentions: [m.sender],
      newsletter: {
      name: '𝐓𝐄𝐀𝐌 𝐃𝐄𝐕𝐎𝐍𝐈𝐂 || 𝑩𝑶𝑻',
      jid: '0029VbC75tvHltY0oNSC4m3z@newsletter'
    },
    }, reply_status);
    
  } catch (error) {
    console.error(error.messsage);
    m.react("❌")
  }
}

test.category = "search";
test.usage = ["بينترست"];
test.command = ["بين", "بينترست", "pinterest"];
export default test;